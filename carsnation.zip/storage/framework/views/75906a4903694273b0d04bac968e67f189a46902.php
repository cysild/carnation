<?php $__env->startSection('title','List'); ?>


<?php $__env->startSection('content'); ?>

<!-- Used ferrari start -->
	<section class="used-ferrari fl w100">
		<div class="container">
			<p class="text-right">Home/
				<?php if($ctype): ?>
				<span class="navigation-color"><?php echo e(ucfirst($ctype)); ?><?php if($cmake): ?> / <?php echo e(ucfirst($cmake)); ?> <?php endif; ?></span>
				<?php endif; ?>

			</p>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 filter-padding">
					<div class="filter fl w100">
						<p class="avenir-demi">Filter</p>
						<form name="filter-form">
							<select id="make" >
								<option value="<?php echo e(url('/'.$ctype)); ?>">Select model</option>
<?php $__currentLoopData = $make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e(url('/'.$ctype)); ?>/<?php echo e(str_slug($make->make)); ?>"  <?php if($cmake == str_slug($make->make)): ?> selected <?php endif; ?>><?php echo e($make->make); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</form>
					</div>

					<div class="request-callback fl w100">
						<h4 class="text-center avenir-demi">YOU WANT TO KNOW MORE?</h4>
						<p class="text-center">Request call back</p>
						       <div class="center-block msg">
                    <div class="alert alert-success" style="display:none"></div>
                    <div class="alert alert-danger" style="display:none"></div>
                  </div>
							<form  name="request-form" id="request">
								<div class="form-group">
							      <input type="text" class="form-control" id="name" placeholder="Name" name="name" required="">
							    </div>
							    <div class="form-group">
							      <input type="email" class="form-control" id="email" placeholder="Email" name="email" required="">
							    </div>
							    <?php echo e(csrf_field()); ?>

							    <div class="form-group">
							      <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required="">
							    </div>
							    <button  type="submit" class="avenir-demi">REQUEST CALL BACK</button>
							</form> 
					</div>
				</div>
				<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
					<h3 class="avenir-demi">Car Type <span class="avenir-light"><?php echo e(ucfirst($ctype)); ?></span>
					</h3>
					<div class="border-bm"></div>
		
					<div class="border-bm-2"></div>
					<div class="row">
<?php if(count($type) > 0): ?>

										<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<a href="<?php echo e(url('/'.str_slug($lists->make).'/'.$lists->id.'/'.str_slug($lists->title))); ?>">

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 car_collection_list">
					<img src="<?php echo e(url('images/listing/base/thumb/'.$lists->base)); ?>">
					<p class="avenir-demi"><?php echo e(str_limit(ucfirst($lists->title),25,'..')); ?>

					<?php if($lists->year): ?>
						<span class="latest-models"><?php echo e($lists->year); ?></span>
					<?php endif; ?>
					</p>
					<?php if($lists->driven): ?>
					<p class="avenir-light">KMS <?php echo e($lists->driven); ?>

					<?php if($lists->fuel): ?>
						<span class="latest-models">FUEL <?php echo e($lists->fuel); ?></span>
					<?php endif; ?>
					</p>
					<?php endif; ?>


					<?php if($lists->price): ?>
					<p class="avenir-demi"><?php echo e(Helper::price($lists->price)); ?>

						<?php if($lists->booked): ?>
						<span class="latest-models">
							<a class="booked">Booked</a>
						</span>
						<?php endif; ?>
					</p>
					<?php endif; ?>
				</div>
			</a>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php else: ?>

				<h2>No cars Found</h2>
					<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End -->


	<!-- About Ferrari start -->
	<?php if($desc): ?>
	<section class="about-ferrari fl w100">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">	
				</div>
				<div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
					<h3 class="avenir-demi">About <span class="avenir-light"><?php echo e($ctype); ?></span></h3>
					<div class="border-bm"></div>
					<?php echo $desc; ?>

				</div>
			</div>
		</div>
	</section>
	<!-- End -->
<?php endif; ?>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('js'); ?>


<script type="text/javascript">



	        $(function(){
      // bind change event to select
      $('#make').on('change', function () {
          var url = $(this).val(); // get selected value

     

          if (url) { // require a URL
              window.location = url; // redirect
          }
          return false;
      });
    });
</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>