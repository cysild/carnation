<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Make extends Model
{
    //
        protected $table = 'car_make';

}
