<?php $__env->startSection('title','Details'); ?>


<?php $__env->startSection('content'); ?>

<!-- Used ferrari start -->
	<section class="used-ferrari-california fl w100"> 
		<div class="container">
			<p class="text-right">Home/<?php echo e($data->make); ?>/
				<span class="navigation-color"><?php echo e(ucfirst($data->title)); ?></span>
			</p>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div id="owl-four" class="owl-carousel owl-theme">

							<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(Helper::ImageExist($img)): ?>
							<div class="item">
										<a data-fancybox="gallery" href="<?php echo e(Helper::ImageExist($img)); ?>">
								<img  src="<?php echo e(Helper::ImageExist($img)); ?>">
</a>
						
							</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="vehicle-details">
						<h3 class="avenir-demi"><?php echo e($data->title); ?></h3>
						<?php if($data->booked): ?>
						<a href="#" class="booked">Booked</a>
						<?php endif; ?>
						<h3 class="avenir-demi"><?php echo e(Helper::price($data->price)); ?></h3>
						<table>
							<?php if($data->year): ?>
	  					  <tr>
						    <td>Registration Year</td>
						    <td><?php echo e($data->year); ?></td>
						  </tr>
						  <?php endif; ?>
						  <tr>
						    <td>Vehicle Type</td>
						    <td><?php echo e($data->type); ?></td>
						  </tr>
						  <tr>
						    <td>Fuel type</td>
						    <td><?php echo e($data->fuel); ?></td>
						  </tr>
						  <?php if($data->driven): ?>
						  <tr>
						    <td>Kms Driven</td>
						    <td><?php echo e($data->driven); ?></td>
						  </tr>
						  <?php endif; ?>
						  <?php if($data->exterior): ?>	
						  <tr>
						    <td>Exterior</td>
						    <td><?php echo e($data->exterior); ?></td>
						  </tr>
						  <?php endif; ?>

						  	  <?php if($data->interior): ?>	
						  <tr>
						    <td>Exterior</td>
						    <td><?php echo e($data->interior); ?></td>
						  </tr>
						  <?php endif; ?>
					
						</table>
					</div>
					</div>
				</div>
				<div class="share-experience">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-x-12">
							<p class="fl">Share your experience with friends</p>
							<div class="topbar-icons fl">
								<span class="icons">
									<a href="#">
										<i class="fa fa-facebook" aria-hidden="true">
										</i>
									</a>
								</span>
								<span class="icons">
									<a href="#">
										<i class="fa fa-twitter" aria-hidden="true"></i>
									</a>
								</span>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-x-12">
							<div class="reserve-car">
						<a href="#" data-toggle="modal" data-target="#myModal2">REQUEST CALL BACK</a>
								<a href="#">RESERVE CAR NOW</a>
							</div>
						</div>
					</div>
				</div>
	</section>
	<!-- End -->


	<!-- Exterior gallery starts -->
	<section class="extr-intr-gallery fl w100">
		<div class="container">
			<div class="row">
		<?php $ext = json_decode($data->ext); ?>

<?php if(count($ext)>0): ?>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<h3 class="avenir-demi">Exterior <span class="avenir-light">Gallery</span></h3>
					<div class="row">
				

						 	<?php $__currentLoopData = $ext; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(Helper::ImageExist("/images/listing/exterior/".$img)): ?>
										<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
														<a data-fancybox="gallaery" href="<?php echo e(Helper::ImageExist("/images/listing/exterior/".$img)); ?>">
						 	<img src="<?php echo e(Helper::ImageExist("/images/listing/exterior/".$img)); ?>"></a>
						 </a>
						</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
		
					</div>

					<div class="hgap20"></div>
	

				</div>
				<?php endif; ?>
	<?php $ext = json_decode($data->iimg); ?>

<?php if(count($ext)>0): ?>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<h3 class="avenir-demi">Interior <span class="avenir-light">Gallery</span></h3>
					<div class="row">
						<?php $ext = json_decode($data->iimg); ?>

						 	<?php $__currentLoopData = $ext; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if(Helper::ImageExist("/images/listing/interior/".$img)): ?>
					

										<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
															<a data-fancybox="gallaery" href="<?php echo e(Helper::ImageExist("/images/listing/interior/".$img)); ?>">
						 	<img src="<?php echo e(Helper::ImageExist("/images/listing/interior/".$img)); ?>">
						 </a>
						</div>

							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					</div>
		<?php endif; ?>
				</div>
			</div>	
		</div>
	</section>

	<!-- End -->

	<!-- overview section starts -->
	<section class="overview fl w100">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div id="exTab3">	
						<div id="exTab3">	
							<ul class="nav nav-tabs">
								<li class="active">
					        		<a  href="#1" data-toggle="tab"><span class="brands-pic"></span>OVERVIEW</a>
								</li>
								<li>
									<a href="#2" data-toggle="tab"><span class="price-pic"></span>FEATURES</a>
								</li>
								<li>
									<a href="#3" data-toggle="tab"><span class="price-pic"></span>SPECIFICATIONS</a>
								</li>
							</ul>
			  			</div>
						<div class="tab-content">
						  	<div class="tab-pane active" id="1">
						  		<table>

	  	  <?php if($data->price): ?>	
						  	<tr>
						  				<td>Price</td>
						  				<td><?php echo e(Helper::price($data->price)); ?></td>
						  			</tr>
						<?php endif; ?>

						  	  <?php if($data->transmission): ?>	
						  	<tr>
						  				<td>Transmission</td>
						  				<td><?php echo e($data->transmission); ?></td>
						  			</tr>
						<?php endif; ?>

						<?php if($data->year): ?>
	  					  <tr>
						    <td>Model Year</td>
						    <td><?php echo e($data->year); ?></td>
						  </tr>
						  <?php endif; ?>
						  <tr>
						    <td>Vehicle Type</td>
						    <td><?php echo e($data->type); ?></td>
						  </tr>
						  <tr>
						    <td>Fuel type</td>
						    <td><?php echo e($data->fuel); ?></td>
						  </tr>
						  <?php if($data->driven): ?>
						  <tr>
						    <td>Kms Driven</td>
						    <td><?php echo e($data->driven); ?></td>
						  </tr>
						  <?php endif; ?>
						  <?php if($data->exterior): ?>	
						  <tr>
						    <td>Exterior</td>
						    <td><?php echo e($data->exterior); ?></td>
						  </tr>
						  <?php endif; ?>

						  	  <?php if($data->interior): ?>	
						  <tr>
						    <td>Exterior</td>
						    <td><?php echo e($data->interior); ?></td>
						  </tr>
						  <?php endif; ?>


						  	  <?php if($data->register_year): ?>	
						  	<tr>
						  				<td>Registeres at</td>
						  				<td><?php echo e($data->register_year); ?></td>
						  			</tr>

<?php endif; ?>

			


							  	  <?php if($data->color): ?>	
						  	<tr>
						  				<td>Color</td>
						  				<td><?php echo e($data->color); ?></td>
						  			</tr>
						<?php endif; ?>


			 <?php if($data->owners): ?>	
						  			<tr>
						  				<td>No. of Owner(s)</td>
						  				<td><?php echo e($data->owners); ?></td>
						  			</tr>
						  			<?php endif; ?>
						  					 <?php if($data->insurance): ?>	

						  			<tr>
						  				<td>Insurance</td>
						  				<td><?php echo e($data->insurance); ?></td>
						  			</tr>
						  			<?php endif; ?>
						  						 <?php if($data->life_time_tax): ?>	
						  			<tr>
						  				<td>Life Time Tax</td>
						  				<td><?php echo e($data->life_time_tax); ?></td>
						  			</tr>
<?php endif; ?>

						  		</table>


							</div>
							<div class="tab-pane" id="2">
		
						  		
						  		<?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<li><?php echo e($f->features); ?></li>
						  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div class="tab-pane" id="3">
						  <?php echo $data->spec; ?>

							</div>
						</div>
  					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<div class="car-delivery">
						<h3 class="avenir-demi">Similar <span class="avenir-light">Cars</span>
						</h3>
						<div class="border-bm"></div>
						<div id="owl-five" class="owl-carousel owl-theme">
										<?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<a href="<?php echo e(url('/'.str_slug($featured->make).'/'.$featured->id.'/'.str_slug($featured->title))); ?>">

					<div class="item">
						<img src="<?php echo e(url('images/listing/base/'.$featured->base)); ?>">
						<p class="avenir-demi"><?php echo e(str_limit(ucfirst($featured ->title),25,'..')); ?>

					<?php if($featured ->year): ?>
						<span class="latest-models"><?php echo e($featured ->year); ?></span>
					<?php endif; ?>
				</p>

								<?php if($featured ->driven): ?>
					<p class="avenir-light">KMS <?php echo e($featured ->driven); ?>

					<?php if($featured ->fuel): ?>
						<span class="latest-models">FUEL <?php echo e($featured ->fuel); ?></span>
					<?php endif; ?>
					</p>
					<?php endif; ?>

						<?php if($featured ->price): ?>
					<p class="avenir-demi"><?php echo e(Helper::price($featured ->price)); ?>

						<?php if($featured ->booked): ?>
				
						<?php endif; ?>
					</p>
					<?php endif; ?>

			
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End -->


	<!-- Request form modal -->
					<div class="modal fade" id="myModal2" role="dialog">
						<div class="modal-dialog">
							<!-- Modal content-->
								<div>
									<button type="button" class="close" data-dismiss="modal">&times;</button>
								</div>
								<div class="modal-body">
										       <div class="center-block msg">
                    <div class="alert alert-success" style="display:none"></div>
                    <div class="alert alert-danger" style="display:none"></div>
                  </div>

									<div class="used-ferrari">
										<div class="request-callback fl w100">
											<h4 class="text-center avenir-demi">YOU WANT TO KNOW MORE?</h4>
											<p class="text-center">Request call back</p>
											<!-- <div class="form-area" ng-app=''>  -->
												<form  name="reqform" method="post" action="#" class="reqform" id="request">
													<?php echo e(csrf_field()); ?>

													<div class="form-group">
														<input type="text" class="form-control" id="name" placeholder="Name" name="name" ng-model="name" required>
														<p><span ng-show="reqform.name.$dirty && reqform.name.$error.required" class="red-txt" >Required</span></p>
													</div>
													<div class="form-group">
														<input type="email" class="form-control" id="email" placeholder="Email" name="email" ng-model="email" required>
														<p>
															<span ng-show="frm.email.$dirty && reqform.email.$error.required" class="red-txt">Required </span>
															<span ng-show="frm.email.$dirty && reqform.email.$error.email" class="red-txt">Not an email </span>
														</p>
													</div>
													<div class="form-group">
														<input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" ng-model="phone" required ng-pattern="/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/">
														<p>
															<span ng-show="frm.phone.$dirty && reqform.phone.$error.required" class="red-txt">Required</span> 
															<span ng-show="frm.phone.$dirty && reqform.phone.$error.pattern" class="red-txt">Must be a valid phone number</span>
														</p>
													</div>
													<input type="submit" name="reqsubmit" id="reqsubmit" class="reqsubmit avenir-demi" value="REQUEST CALL BACK">
													<?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												</form>
												<!-- </div>  -->
											</div>
										</div>
									</div>
							</div>
						</div>
						<!-- end -->

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(url('js/owl/owl.carousel.min.js')); ?>"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.js"></script>
	<script>
		$('#owl-four').owlCarousel({
		    loop:true,
		    margin:10,
		    nav:true,
			autoplay:false,
			autoplayTimeout:3000,
		    responsive:{
		        0:{
		            items:1
		        },
		        600:{
		            items:1
		        },
	  	        1000:{
		            items:1
		        }
		    }
		});
		$('#owl-five').owlCarousel({
		    loop:true,
		    margin:10,
		    nav:true,
			autoplay:false,
			autoplayTimeout:3000,
		    responsive:{
		        0:{
		            items:1
		        },
		        600:{
		            items:1
		        },
	  	        1000:{
		            items:2
		        }
		    }
		});
	</script>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>