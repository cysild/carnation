<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
 
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo e($page['title']); ?>

        <small><?php echo e($page['subtitle']); ?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li><a href="javascript:void(0);"><?php echo e($page['basemenu']); ?></a></li>
        <li class="active"><?php echo e($page['currenmenu']); ?></li>
      </ol>
    </section>

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo e($page['title']); ?> - <?php echo e($page['subtitle']); ?></h3>
              <div class="box-body">
                <button type="button" class="btn btn-default" style="float:right;" data-toggle="modal" id="modal-add-open">
                Add <?php echo e($page['content']); ?>

              </button>
              </div>
            </div>
            <?php echo $__env->make('cars.features.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table  class="table table-bordered table-hover">
                <thead>
                <tr>
                  <?php $__currentLoopData = $heading; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th><?php echo e(ucfirst($head)); ?></th>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->          
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

  <style type="text/css">
@media (min-width: 768px){
.modal-dialog {
    width: 500px;
    margin: 30px auto;
}
}
</style>
        <?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script src="<?php echo e(url('/admin')); ?>/js/bootbox.min.js"></script>

<script>
    $(document).ready(function(){



           $('#modal-add-open').on('click', function() {
           $('.modal-title').html('<h4><b>Add Car Features</b></h4>');
         });



          $('.table').DataTable({
              processing: true,
              serverSide: true,
              ajax: '<?php echo e($page['table_url']); ?>',
              columns:<?php echo $table; ?>

          });

    $('#add-data').submit(function(e){
               e.preventDefault();       
             var url = "<?php echo e($page['save_url']); ?>";
            var mydata = new FormData(this);
             AddData(url,mydata);
    });

      $('body').on('click', '[data-act=ajax-modal]', function (e) {
            var id = $(this).data('id');
              getData(id); 
      });  

      $('body').on('click', '[data-act=ajax-modal-del]', function (e) {
            var id = $(this).data('id');
                bootbox.confirm("Are you sure want to delete?", function(result) {
                  if(result){
            $.ajax({
              type:'GET',
              url:"<?php echo e($page['delete_url']); ?>/" + id,
              success: function(data)
              {
                bootbox.alert(data.success, )
                    $('.alert').show();
                    $('.alert-danger').html('<p>'+data.success+'</p>');
                    $('.table').DataTable().ajax.reload();
              }
            });
          }
            });
      });


var imageurl ="<?php echo e(url('/images/features')); ?>/";

function getData(id){
   $('.modal-footer .btn-primary').show();
           $(".msg").hide();
           $("#form").show();
           $('.alert-success').hide();
           $("#add-data").show();
           $('.modal-title').html('<h4><b>Edit Car Features</b></h4>');
            $.ajax({
              type:'GET',
              url:"<?php echo e($page['view_url']); ?>/" + id,
              success: function(data)
              {
                $('#add-data')[0].reset();
            $.each(data.html, function(key, value)
             {
              $('[name='+key+']').val(value);
             }
     );
     
    if(data.html.images){


              var appendimg = '';
              
                appendimg += '<a data-act="ajax-del-id" href ="#"> <img class="img" src="'+imageurl+data.html.images+'" width="50px;"/></a>';
            
                 $('.images').empty().append(''+appendimg);
                $('.image').empty().append('<input type="hidden" name="img" value="'+data.html.images+'"/>');
              }
          
                $('#modal-add').modal('show');
             }
            });
}


$('body').on('click', '[data-act=ajax-del-id]', function (e) {
             var id = $(this).data('id');
             var pid = $('[name=id]').val();
              bootbox.confirm("Are you sure want to delete?", function(result) {
              if(result){
              delimages(id,pid);
             $('.table').DataTable().ajax.reload();
            }
        });
         //alert(pid);
      });

function delimages(i,p){
     $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                  }
              });
   $.ajax({
    type: "POST",
    url: "<?php echo e(url('/admin/features/images/del')); ?>",
    data:{

      "p":p,
      "i":i,
      "_token": "<?php echo e(csrf_token()); ?>",

    },
    success: function(data){
     // alert(data);
                      bootbox.alert(data.success, )

                           //  var id = $(i).data('id').hide();

                 $('.images').hide();
                 
             $('.table').DataTable().ajax.reload();

                            
                                


    }
    });


}
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>