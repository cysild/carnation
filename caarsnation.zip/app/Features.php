<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Features extends Model
{
    //

         protected $table = 'car_features';

    
}
